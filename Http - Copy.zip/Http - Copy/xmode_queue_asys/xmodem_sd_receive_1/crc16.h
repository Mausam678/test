#ifndef CRC16_H
#define CRC16_H

#include <stdint.h>

// Function to calculate CRC16 for XMODEM
uint16_t crc16_ccitt(const uint8_t *buf, int len);

#endif // CRC16_H
