#include "crc16.h"

// Polynomial: XMODEM CRC uses 0x1021 (same as CRC-CCITT)
#define POLY 0x1021

// Function to calculate CRC16 (XMODEM)
uint16_t crc16_ccitt(const uint8_t *buf, int len) {
  uint16_t crc = 0;
  for (int i = 0; i < len; i++) {
    crc ^= (buf[i] << 8);
    for (int j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ POLY;
      } else {
        crc = crc << 1;
      }
    }
  }
  return crc;
}
