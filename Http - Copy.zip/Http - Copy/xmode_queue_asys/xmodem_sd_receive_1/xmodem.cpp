// main.cpp
#include <stdio.h>
#include "xmodem.h"

int _inbyte(unsigned short timeout) // msec timeout
{
  Serial2.setTimeout(timeout);
  uint8_t RecievedByte = 0;
  int ret = Serial2.readBytes(&RecievedByte, 1);

  if (ret == 0)
  {
    Serial.printf("Serial2 Read Error %d\r\n", RecievedByte);
    return -1;
  }

  return RecievedByte;
}

void _outbyte(char c)
{
  Serial2.write(c);
}

void flushinput(void)
{
  while (_inbyte((DLY_1S * 3) >> 1) >= 0)
  {
    // Wait for the input buffer to clear
  }
}

static int check(int crc, const unsigned char *buf, int sz)
{
  if (crc)
  {
    unsigned short crcValue = crc16_ccitt(buf, sz);
    unsigned short tcrc = (buf[sz] << 8) + buf[sz + 1];
    if (crcValue == tcrc)
      return 1;
  }
  else
  {
    unsigned char cks = 0;
    for (int i = 0; i < sz; ++i)
      cks += buf[i];
    
    if (cks == buf[sz])
      return 1;
  }
  return 0;
}

int xmodemReceive(unsigned char *dest, int destsz)
{
  unsigned char xbuff[1030];
  unsigned char *p;
  int bufsz, crc = 0;
  unsigned char trychar = 'C';
  unsigned char packetno = 1;
  int i, c, len = 0;
  int retry, retrans = MAXRETRANS;

  for (;;)
  {
    for (retry = 0; retry < 16; ++retry)
    {
      if (trychar) _outbyte(trychar);
      if ((c = _inbyte(DLY_1S << 1)) >= 0)
      {
        switch (c)
        {
          case SOH:
            bufsz = 128;
            goto start_recv;
          case STX:
            bufsz = 1024;
            goto start_recv;
          case EOT:
            flushinput();
            _outbyte(ACK);
            return len;
          case CAN:
            if ((c = _inbyte(DLY_1S)) == CAN)
            {
              flushinput();
              _outbyte(ACK);
              return -1;
            }
            break;
          default:
            break;
        }
      }
    }
    if (trychar == 'C')
    {
      trychar = NAK;
      continue;
    }
    flushinput();
    _outbyte(CAN);
    _outbyte(CAN);
    _outbyte(CAN);
    return -2;

start_recv:
    if (trychar == 'C') crc = 1;
    trychar = 0;
    p = xbuff;
    *p++ = c;
    for (i = 0; i < (bufsz + (crc ? 1 : 0) + 3); ++i)
    {
      if ((c = _inbyte(DLY_1S)) < 0) goto reject;
      *p++ = c;
    }

    if (xbuff[1] == (unsigned char)(~xbuff[2]) &&
        (xbuff[1] == packetno || xbuff[1] == (unsigned char)(packetno - 1)) &&
        check(crc, &xbuff[3], bufsz))
    {
      if (xbuff[1] == packetno)
      {
        int count = destsz - len;
        if (count > bufsz) count = bufsz;
        if (count > 0)
        {
          memcpy(&dest[len], &xbuff[3], count);
          len += count;
        }
        ++packetno;
        retrans = MAXRETRANS + 1;
      }
      if (--retrans <= 0)
      {
        flushinput();
        _outbyte(CAN);
        _outbyte(CAN);
        _outbyte(CAN);
        return -3;
      }
      _outbyte(ACK);
      continue;
    }

reject:
    flushinput();
    _outbyte(NAK);
  }
}

int xmodemTransmit(const char *src, int srcsz)
{
  unsigned char xbuff[1030];
  int bufsz, crc = -1;
  unsigned char packetno = 1;
  int i, c, len = 0;
  int retry;

  for (;;)
  {
    for (retry = 0; retry < 16; ++retry)
    {
      if ((c = _inbyte(DLY_1S << 1)) >= 0)
      {
        switch (c)
        {
          case 'C':
            crc = 1;
            goto start_trans;
          case NAK:
            crc = 0;
            goto start_trans;
          case CAN:
            if ((c = _inbyte(DLY_1S)) == CAN)
            {
              _outbyte(ACK);
              flushinput();
              return -1;
            }
            break;
          default:
            break;
        }
      }
    }
    _outbyte(CAN);
    _outbyte(CAN);
    _outbyte(CAN);
    flushinput();
    return -2;

start_trans:
#ifdef TRANSMIT_XMODEM_1K
    xbuff[0] = STX; bufsz = 1024;
#else
    xbuff[0] = SOH; bufsz = 128;
#endif
    xbuff[1] = packetno;
    xbuff[2] = ~packetno;
    c = srcsz - len;
    if (c > bufsz) c = bufsz;
    if (c > 0)
    {
      memset(&xbuff[3], 0, bufsz);
      memcpy(&xbuff[3], &src[len], c);
      if (c < bufsz) xbuff[3 + c] = CTRLZ;
      if (crc)
      {
        unsigned short ccrc = crc16_ccitt(&xbuff[3], bufsz);
        xbuff[bufsz + 3] = (ccrc >> 8) & 0xFF;
        xbuff[bufsz + 4] = ccrc & 0xFF;
      }
      else
      {
        unsigned char ccks = 0;
        for (i = 3; i < bufsz + 3; ++i) ccks += xbuff[i];
        xbuff[bufsz + 3] = ccks;
      }
      for (retry = 0; retry < MAXRETRANS; ++retry)
      {
        for (i = 0; i < bufsz + 4 + (crc ? 1 : 0); ++i) _outbyte(xbuff[i]);
        if ((c = _inbyte(DLY_1S)) >= 0)
        {
          switch (c)
          {
            case ACK:
              ++packetno;
              len += bufsz;
              goto start_trans;
            case CAN:
              if ((c = _inbyte(DLY_1S)) == CAN)
              {
                _outbyte(ACK);
                flushinput();
                return -1;
              }
              break;
            case NAK:
            default:
              break;
          }
        }
      }
      _outbyte(CAN);
      _outbyte(CAN);
      _outbyte(CAN);
      flushinput();
      return -4;
    }
    else
    {
      for (retry = 0; retry < 10; ++retry)
      {
        _outbyte(EOT);
        if ((c = _inbyte(DLY_1S << 1)) == ACK) break;
           if (c == ACK) 
        return len; // Transmission successful
    }
    _outbyte(CAN);
    _outbyte(CAN);
    _outbyte(CAN);
    flushinput();
    return -5;
  }
}
}
int xmodemTransmitFilefrmSD(const char *fname, int srcsz)
{
  File file = SD_MMC.open(fname);
  if (!file) {
    Serial.printf("Error opening file %s\n", fname);
    return -1;
  }
  
  unsigned char xbuff[1030];
  int bufsz, crc = -1;
  unsigned char packetno = 1;
  int i, c, len = 0;
  int retry;

  for (;;)
  {
    for (retry = 0; retry < 16; ++retry)
    {
      if ((c = _inbyte(DLY_1S << 1)) >= 0)
      {
        switch (c)
        {
          case 'C':
            crc = 1;
            goto start_trans;
          case NAK:
            crc = 0;
            goto start_trans;
          case CAN:
            if ((c = _inbyte(DLY_1S)) == CAN)
            {
              _outbyte(ACK);
              flushinput();
              file.close();
              return -1;
            }
            break;
          default:
            break;
        }
      }
    }
    _outbyte(CAN);
    _outbyte(CAN);
    _outbyte(CAN);
    flushinput();
    file.close();
    return -2;

start_trans:
#ifdef TRANSMIT_XMODEM_1K
    xbuff[0] = STX; bufsz = 1024;
#else
    xbuff[0] = SOH; bufsz = 128;
#endif
    xbuff[1] = packetno;
    xbuff[2] = ~packetno;
    c = srcsz - len;
    if (c > bufsz) c = bufsz;
    if (c > 0)
    {
      memset(&xbuff[3], 0, bufsz);
      int readBytes = file.read(&xbuff[3], c);
      if (readBytes < bufsz) xbuff[3 + readBytes] = CTRLZ;
      
      if (crc)
      {
        unsigned short ccrc = crc16_ccitt(&xbuff[3], bufsz);
        xbuff[bufsz + 3] = (ccrc >> 8) & 0xFF;
        xbuff[bufsz + 4] = ccrc & 0xFF;
      }
      else
      {
        unsigned char ccks = 0;
        for (i = 3; i < bufsz + 3; ++i) ccks += xbuff[i];
        xbuff[bufsz + 3] = ccks;
      }

      for (retry = 0; retry < MAXRETRANS; ++retry)
      {
        for (i = 0; i < bufsz + 4 + (crc ? 1 : 0); ++i) _outbyte(xbuff[i]);
        if ((c = _inbyte(DLY_1S)) >= 0)
        {
          switch (c)
          {
            case ACK:
              ++packetno;
              len += bufsz;
              goto start_trans;
            case CAN:
              if ((c = _inbyte(DLY_1S)) == CAN)
              {
                _outbyte(ACK);
                flushinput();
                file.close();
                return -1;
              }
              break;
            case NAK:
            default:
              break;
          }
        }
      }
      _outbyte(CAN);
      _outbyte(CAN);
      _outbyte(CAN);
      flushinput();
      file.close();
      return -4;
    }
    else
    {
      for (retry = 0; retry < 10; ++retry)
      {
        _outbyte(EOT);
        if ((c = _inbyte(DLY_1S << 1)) == ACK) break;
      }
      if (c == ACK)
      {
        file.close();
        return len; // Transmission successful
      }
    }
    _outbyte(CAN);
    _outbyte(CAN);
    _outbyte(CAN);
    flushinput();
    file.close();
    return -5;
  }
}

// void setup()
// {
//   // Initialize Serial2 for XMODEM communication
//   Serial2.begin(9600, SERIAL_8N1, 16, 17);  // RX pin: GPIO16, TX pin: GPIO17
//   Serial.begin(115200);  // Debugging output

//   // Initialize SD card
//   if (!SD_MMC.begin()) {
//     Serial.println("Card Mount Failed");
//     return;
//   }

//   uint64_t cardSize = SD_MMC.cardSize() / (1024 * 1024);
//   Serial.printf("SD Card Size: %lluMB\n", cardSize);
// }

// void loop()
// {
//   // This is where you would use the XMODEM transfer
//   // Uncomment the following lines based on whether you want to receive or send
//   // unsigned char buffer[1024]; // Example buffer for receiving
  
//   // Example of receiving a file using XMODEM
//   // int result = xmodemReceive(buffer, sizeof(buffer));
//   // Serial.printf("XMODEM receive result: %d\n", result);
  
//   // Example of transmitting a file from SD card using XMODEM
//   int result = xmodemTransmitFilefrmSD("/hello.txt", 1024);
//   Serial.printf("XMODEM transmit result: %d\n", result);
  
//   delay(5000);  // Pause to avoid rapid execution
// }

