// xmodem.h
#ifndef XMODEM_H
#define XMODEM_H

#include "HardwareSerial.h"
#include "SD_MMC.h"
#include "crc16.h"

// XMODEM control characters
#define SOH  0x01
#define STX  0x02
#define EOT  0x04
#define ACK  0x06
#define NAK  0x15
#define CAN  0x18
#define CTRLZ 0x1A

// Constants for XMODEM
#define DLY_1S 1000
#define MAXRETRANS 10
#define TRANSMIT_XMODEM_1K

// Function Prototypes
int _inbyte(unsigned short timeout); 
void _outbyte(char c);
void flushinput(void);
int xmodemReceive(unsigned char *dest, int destsz);
int xmodemTransmit(const char *src, int srcsz);
int xmodemTransmitFilefrmSD(const char *fname, int srcsz);

#endif // XMODEM_H
