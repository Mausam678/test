#ifndef XMODEMSD_H
#define XMODEMSD_H

#include <HardwareSerial.h>
#include <SD_MMC.h>

// XMODEM Protocol Constants
#define SOH 0x01  // Start of Header
#define EOT 0x04  // End of Transmission
#define ACK 0x06  // Acknowledge
#define NAK 0x15  // Negative Acknowledge
#define CAN 0x18  // Cancel

// Buffer size for XMODEM block (128 bytes for data + 5 bytes for header and checksum)
#define XMODEM_BLOCK_SIZE 1030
#define XMODEM_BLOCK_DATA_SIZE 1024
#define MAX_RETRIES 10

extern HardwareSerial mySerial1; // Declare the HardwareSerial instance

void setupXmodemSD();
void sendXmodem(const char *data, size_t length);
void receiveXmodem();
void sendFileFromSD(const char *filename);

#endif // XMODEMSD_H
