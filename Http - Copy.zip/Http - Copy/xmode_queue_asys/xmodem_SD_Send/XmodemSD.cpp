#include "XmodemSD.h"

// Initialize the serial port for UART communication
HardwareSerial mySerial1(1);

void setupXmodemSD() {
    Serial.begin(115200);
    pinMode(15, INPUT_PULLUP);
  pinMode(2, INPUT_PULLUP);
    mySerial1.begin(9600, SERIAL_8N1, 13, 12);  // UART1 - RX on GPIO16, TX on GPIO17

    // Initialize the SD card
  if (!SD_MMC.begin("/sdcard", true, false, 1000)) {
        Serial.println("SD Card Mount Failed");
        return;
    }

    Serial.println("Ready to send/receive data using XMODEM protocol.");
}

void sendXmodem(const char *data, size_t length) {
    uint8_t blockNumber = 1;
    size_t dataSent = 0;
    uint8_t buffer[XMODEM_BLOCK_SIZE];
    uint8_t retries = 0;
    bool acknowledged = false;

    while (dataSent < length && retries < MAX_RETRIES) {
        // Fill the buffer with SOH, block number, and data
        buffer[0] = SOH;
        buffer[1] = blockNumber;
        buffer[2] = ~blockNumber;
        size_t bytesToSend = (length - dataSent > XMODEM_BLOCK_DATA_SIZE) ? XMODEM_BLOCK_DATA_SIZE : length - dataSent;
        memcpy(&buffer[3], &data[dataSent], bytesToSend);

        // Zero-pad if less than 128 bytes
        if (bytesToSend < XMODEM_BLOCK_DATA_SIZE) {
            memset(&buffer[3 + bytesToSend], 0x1A, XMODEM_BLOCK_DATA_SIZE - bytesToSend);  // Pad with Ctrl-Z (0x1A)
        }

        // Calculate checksum (simple XOR of all data bytes)
        uint8_t checksum = 0;
        for (int i = 3; i < XMODEM_BLOCK_SIZE - 1; i++) {
            checksum ^= buffer[i];
        }
        buffer[XMODEM_BLOCK_SIZE - 1] = checksum;

        // Send the block
        mySerial1.write(buffer, XMODEM_BLOCK_SIZE);
        Serial.println("Block sent, waiting for ACK or NAK.");

        // Wait for ACK/NAK from receiver
        unsigned long startTime = millis();
        while (millis() - startTime < 1000) {  // 1 second timeout
            if (mySerial1.available()) {
                uint8_t response = mySerial1.read();
                if (response == ACK) {
                    Serial.println("ACK received.");
                    acknowledged = true;
                    break;
                } else if (response == NAK) {
                    Serial.println("NAK received, retrying.");
                    acknowledged = false;
                    retries++;
                    break;
                }
            }
        }

        if (acknowledged) {
            dataSent += XMODEM_BLOCK_DATA_SIZE;
            blockNumber++;
            retries = 0;  // Reset retries after successful transmission
        } else {
            Serial.println("No response, retrying...");
            retries++;
        }
    }

    // If all data is sent, send EOT (End of Transmission)
    if (dataSent >= length) {
        mySerial1.write(EOT);
        Serial.println("Transmission complete, EOT sent.");
    }
}
/*
void sendFileFromSD(const char *filename) {
    File file = SD_MMC.open(filename);
    if (!file) {
        Serial.println("Failed to open file for reading");
        return;
    }

    size_t fileSize = file.size();
    Serial.print("File size: ");
    Serial.println(fileSize);

    // Allocate buffer for the file data
    char *fileBuffer = (char *)malloc(fileSize);
    if (fileBuffer == NULL) {
        Serial.println("Failed to allocate memory for file data");
        file.close();
        return;
    }

    // Read the entire file into the buffer
    file.read((uint8_t *)fileBuffer, fileSize);

    // Send the file data using XMODEM
    sendXmodem(fileBuffer, fileSize);

    // Clean up
    free(fileBuffer);
    file.close();
}
*/

void sendFileFromSD(const char *filename) {
    File file = SD_MMC.open(filename);
    if (!file) {
        Serial.println("Failed to open file for reading");
        return;
    }

    size_t fileSize = file.size();
    Serial.print("File size: ");
    Serial.println(fileSize);

    uint8_t buffer[XMODEM_BLOCK_DATA_SIZE];
    size_t bytesRead;
    uint8_t blockNumber = 1;

    // Read and send the file data in chunks
    while ((bytesRead = file.read(buffer, XMODEM_BLOCK_DATA_SIZE)) > 0) {
        // Send the current block via XMODEM
        sendXmodem((const char *)buffer, bytesRead);
        blockNumber++;
        delay(100);  // Add delay if needed to prevent overloading the receiver
    }

    // Send EOT (End of Transmission) after the whole file is sent
    mySerial1.write(EOT);
    Serial.println("Transmission complete, EOT sent.");

    file.close();
}

void receiveXmodem() {
    // XMODEM reception logic would go here, if needed.
}
