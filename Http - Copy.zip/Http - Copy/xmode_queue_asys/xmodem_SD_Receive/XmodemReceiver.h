#ifndef XMODEM_RECEIVER_H
#define XMODEM_RECEIVER_H

#include <HardwareSerial.h>

// XMODEM Protocol Constants
#define SOH 0x01  // Start of Header
#define EOT 0x04  // End of Transmission
#define ACK 0x06  // Acknowledge
#define NAK 0x15  // Negative Acknowledge
#define CAN 0x18  // Cancel

// XMODEM block size
#define XMODEM_BLOCK_SIZE 1030
#define XMODEM_DATA_SIZE 1024

// Function prototypes
void setupReceiver();
void receiveXmodem();

#endif // XMODEM_RECEIVER_H
