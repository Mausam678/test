#include "XmodemReceiver.h"

// Define the serial port for communication (use Serial1 or Serial2 for hardware UART)
HardwareSerial mySerial1(1);

// XMODEM protocol constants
#define SOH 0x01
#define EOT 0x04
#define NAK 0x15
#define ACK 0x06
#define CAN 0x18
#define XMODEM_DATA_SIZE 128
#define XMODEM_BLOCK_SIZE (XMODEM_DATA_SIZE + 4)

// Function to setup the serial port
void setupReceiver() {
    Serial.begin(115200);
    mySerial1.begin(9600, SERIAL_8N1, 13, 12); // Configure UART for RX=GPIO16, TX=GPIO17
    Serial.println("XMODEM Receiver Ready");
}

// Function to calculate the checksum
uint8_t calculateChecksum(uint8_t *data) {
    uint8_t checksum = 0;
    for (int i = 0; i < XMODEM_DATA_SIZE; i++) {
        checksum += data[i];
    }
    return checksum;
}

// Function to calculate the checksum (XOR)
// uint8_t calculateChecksum(uint8_t *data) {
//     uint8_t checksum = 0;
//     for (int i = 0; i < XMODEM_DATA_SIZE; i++) {
//         checksum ^= data[i];
//     }
//     return checksum;
// }


// Function to receive data using the XMODEM protocol
void receiveXmodem() {
    uint8_t buffer[XMODEM_BLOCK_SIZE];
    uint8_t blockNumber = 1;
    bool endOfTransmission = false;
    int retryCount = 0;

    // Start receiving by sending NAK
    Serial.println("Waiting for transmission...");
    mySerial1.write(NAK);

    while (!endOfTransmission) {
        if (mySerial1.available() > 0) {
            // Read the first byte
            uint8_t startByte = mySerial1.read();

            // If SOH, expect a data block
            if (startByte == SOH) {
                // Read the block number, its complement, data, and checksum
                buffer[0] = mySerial1.read();   // Block number
                buffer[1] = mySerial1.read();   // Block number complement
                mySerial1.readBytes(buffer + 2, XMODEM_DATA_SIZE + 1);  // Data + checksum

                uint8_t receivedChecksum = buffer[XMODEM_BLOCK_SIZE - 1];
                uint8_t calculatedChecksum = calculateChecksum(buffer + 2);

                // Validate block number and checksum
                if (buffer[0] == blockNumber && (buffer[0] + buffer[1]) == 0xFF && receivedChecksum == calculatedChecksum) {
                    // Send ACK to confirm receipt of block
                    mySerial1.write(ACK);
                    Serial.printf("Block %d received and acknowledged.\n", blockNumber);

                    // Handle the received data (you can store it, print it, etc.)
                    Serial.write(buffer + 2, XMODEM_DATA_SIZE);

                    // Move to the next block
                    blockNumber++;
                    retryCount = 0;  // Reset retry counter
                } else {
                    // Send NAK to request retransmission
                    mySerial1.write(NAK);
                    Serial.println("Checksum error, NAK sent.");
                    retryCount++;

                    // If retry count exceeds the limit, cancel the transmission
                    if (retryCount >= 10) {
                        mySerial1.write(CAN);
                        Serial.println("Too many retries, cancelling transmission.");
                        break;
                    }
                }
            } else if (startByte == EOT) {
                // End of transmission
                mySerial1.write(ACK);
                Serial.println("End of transmission received. ACK sent.");
                endOfTransmission = true;
            }
        }
    }

    Serial.println("XMODEM reception completed.");
}
